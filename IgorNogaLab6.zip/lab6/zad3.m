function xout = zad3(T, xin)

    global a;
    xout = a*xin - xin^3;
    
end