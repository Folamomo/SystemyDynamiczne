function xout = vdp(t, xin)

    global eps;
    xout =[0, 1;-1, 0]* xin + [0; eps*xin(2)*(1-xin(1)*xin(1))];
    
end