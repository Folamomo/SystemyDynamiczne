function xout=lorenz(t, xin)
    global sig;
    global r; 
    global b; 

    xout = [sig*(xin(2)-xin(1)); r*xin(1)-xin(2)-xin(1)*xin(3); -b*xin(3)+xin(1)*xin(2)];
end