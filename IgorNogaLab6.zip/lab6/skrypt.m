%Igor Noga
%Zadanie 1 
%W osobnych plikach(vdp.m i lorenz.m), bo lambdy nie mog�
%przechwytywa� zmiennych przez referencj�
%Zadanie 2
T = [0 5];
global eps;
global sig;
global r; 
global b; 
global a;

wpc=[linspace(-5,5,20);linspace(-5,5,20)];
eps =0.1;
figure(1)
hold on
for i=1:length(wpc)
    for j=1:length(wpc)
    [T,X] = ode45(@vdp,T,[wpc(1,i);wpc(2,j)]);
    plot(X(:,1),X(:,2));

    end
    
end
ylim([-10 10])
xlim([-10 10])
title("Trajektorie fazowe oscylatora van der Pola dla eps = " + eps);
hold off


%Zadanie 3

figure(2);
hold on
param = linspace(-5,5,50);
plot(param,sqrt(param));
plot(param,-sqrt(param));
plot(param,zeros(size(param)));
title("Po�o�enia punkt�w r�wnowagi w zale�no�ci od parametru a");
xlabel("a");
ylabel("Punkty r�wnowagi");

hold off
T = [0 3];
wpc=[-3:0.1:3];


a = -0.5;
figure(3);
hold on

for i=1:length(wpc)
    [T,X]=ode45(@zad3,T,wpc(i));
    plot(T,X);
end
hold off
title("x(t)dla a = " + a);
%2) 
a =1;
figure(4);
hold on

for i=1:length(wpc)
    [T,X]=ode45(@zad3,T,wpc(i));
    plot(T,X);
end
title("x(t) dla a = " + a);
hold off

a = 3;
figure(5);
hold on

for i=1:length(wpc)
    [T,X]=ode45(@zad3,T,wpc(i));
    plot(T,X);
end
title("x(t) dla a = " + a);
hold off

%Zadanie 4

figure(6)
hold on
wpc=[linspace(-5,5,10);linspace(-5,5,10);linspace(-5,5,10);];
sig=10; 
r=28; 
b=8/3; 
for i=1:length(wpc)
    for l=1:length(wpc)
        for k=1:length(wpc)
    [T,X] = ode45(@lorenz,T,[wpc(1,i);wpc(2,l);wpc(3,k)]);
    plot3(X(:,1),X(:,2),X(:,3));
        end
    end
end
title("Trajektorie fazowe systemu Lorenza dla sigma = " + sig +", r = "+r+" i b ="+b );
hold off
view(30,30);

figure(7)
hold on
wpc=[linspace(-5,5,10);linspace(-5,5,10);linspace(-5,5,10);];
sig=28; 
r=13; 
b=8; 
for i=1:length(wpc)
    for j=1:length(wpc)
        for k =1:length(wpc)
    [T,X] = ode45(@lorenz,T,[wpc(1,i);wpc(2,j);wpc(3,k)]);
    plot3(X(:,1),X(:,2),X(:,3));
        end 
    end
    
end

title("Trajektorie fazowe systemu Lorenza dla sigma = " + sig +", r = "+r+" i b ="+b );
hold off
view(30,30);


